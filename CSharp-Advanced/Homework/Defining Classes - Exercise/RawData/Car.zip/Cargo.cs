﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _07._Raw_Data
{
    public class Cargo
    {
        public string Type { get; set; }
        public double Weight{ get; set; }
    }
}
