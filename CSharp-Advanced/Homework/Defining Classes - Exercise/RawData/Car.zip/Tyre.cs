﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _07._Raw_Data
{
    public  class Tyre
    {
        public double Age { get; set; }
        public double Pressure { get; set; }
    }
}
