﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _07._Raw_Data
{
    public class Engine
    {
        public double Speed { get; set; }
        public double Power { get; set; }
    }
}
