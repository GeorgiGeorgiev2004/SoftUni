﻿namespace P01_StudentSystem.Data.Common
{
    public static class DBConfig
    {
        public const string ConnectionString =
            "Server=.;Database =StudentSystem;Integrated Security=True;Encrypt=False;";
    }
    
}