﻿namespace PersonInfo
{
    public interface IIdentifiable
    {
        string Id { get; }

    }
}